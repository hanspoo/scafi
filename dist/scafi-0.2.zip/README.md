# scafi

Play framework 1.4.x plugin. Scaffolding html templates for model classes using bootstrap markup: form, detail and table.
