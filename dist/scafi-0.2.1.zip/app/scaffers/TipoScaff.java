package scaffers;

public enum TipoScaff {
	BOOTSTRAP, SEMANTIC_GROOVY

}
